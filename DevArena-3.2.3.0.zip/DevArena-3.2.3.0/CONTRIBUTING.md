If you are going to contribute please be nice to staff and follow guidelines
